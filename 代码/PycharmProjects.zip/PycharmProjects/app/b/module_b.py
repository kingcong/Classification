def funca01():
    print 'in module b... funca01...'


def funca02():
    print 'in module b... funca02...'