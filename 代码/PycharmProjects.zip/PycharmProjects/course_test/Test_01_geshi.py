#!/usr/bin/python

"""
这是我的第一个python程序
"""
if True:
    print "Answer"
    print "True"
else:
    print "Answer"
    print "False"

    