#!/usr/bin/python
# -*- coding: UTF-8 -*-

if True:
    print "True"    # 如果为真
else:
    print 'haha'
print "False"
print 'haha'