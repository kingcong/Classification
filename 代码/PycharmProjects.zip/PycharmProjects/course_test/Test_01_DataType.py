#coding=utf-8

#基本使用
counter = 100          # 整型
miles   = 1000.0       # 浮点
name    = "John"      # 字符串

print counter
print miles
print name

#多重赋值
a = b = c = 1
d, e, f = 1, 2, "john"